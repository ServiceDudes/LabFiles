﻿Configuration MemberServer {
    param 
    (
        [Parameter(Mandatory)] 
        [ValidateSet("Present","Absent")]
        [string]$Ensure
    )
    $MemberVersion = "1.0"
    #Default configurations, for example audit settings, logging settings, logshipping application, etc
    
       Registry MemberConfig {
            Key       = "HKEY_LOCAL_MACHINE\SOFTWARE\AddLevel\DSCConfig\Member"
            ValueName = "MemberVersion"
            ValueData = $MemberVersion
            ValueType = "String"
            Ensure    = $Ensure
            Force     = $True
        }


}
