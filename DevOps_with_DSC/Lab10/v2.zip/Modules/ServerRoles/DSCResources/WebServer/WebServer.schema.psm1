﻿Configuration WebServer{
    param (
        [Parameter(Mandatory)]
        [ValidateSet("Present","Absent")] 
        [string]$Ensure
    )
    $WebVersion = "1.0"

    Registry WebConfig {
        Key       = "HKEY_LOCAL_MACHINE\SOFTWARE\AddLevel\DSCConfig\Web"
        ValueName = "WebVersion"
        ValueData = $WebVersion
        ValueType = "String"
        Ensure    = $Ensure
        Force     = $True
    }

    WindowsFeature IIS-Web-Server {
        Ensure = $Ensure
        Name   = "Web-Server"
    }
    WindowsFeature IIS-Web-WebServer {
        Ensure    = $Ensure
        Name      = "Web-WebServer"
        DependsOn = "[WindowsFeature]IIS-Web-Server"
    }
    WindowsFeature IIS-Web-Common-Http {
        Ensure    = $Ensure
        Name      = "Web-Common-Http"
        DependsOn = "[WindowsFeature]IIS-Web-WebServer"
    }
    WindowsFeature IIS-Web-Static-Content {
        Ensure    = $Ensure
        Name      = "Web-Static-Content"
        DependsOn = "[WindowsFeature]IIS-Web-Common-Http"
    }
    WindowsFeature IIS-Web-Mgmt-Tools {
        Ensure    = $Ensure
        Name      = "Web-Mgmt-Tools"
        DependsOn = "[WindowsFeature]IIS-Web-Server"
    }    
    WindowsFeature Web-Mgmt-Console {
        Ensure    = $Ensure
        Name      = "Web-Mgmt-Console"
        DependsOn = "[WindowsFeature]IIS-Web-Mgmt-Tools"
    }
}
