﻿#$currentModulePath = [Environment]::GetEnvironmentVariable("PSModulePath", "Machine") 
#$newModulePath = $currentModulePath + ";" + "C:\Repos\DSC Composite\v2\Modules"
#[Environment]::SetEnvironmentVariable("PSModulePath", $newModulePath, "Machine")

Configuration ServerConfig {    
    [string]$ConfigurationVersion = "1.0"

    Import-DscResource -ModuleName PSDesiredStateConfiguration -ModuleVersion 1.1
    Import-DscResource -ModuleName ServerRoles 

    Node $AllNodes.NodeName {

        Registry DSCConfig {
            Key       = "HKEY_LOCAL_MACHINE\SOFTWARE\AddLevel\DSCConfig"
            ValueName = "ServerVersion"
            ValueData = $ConfigurationVersion
            ValueType = "String"
            Ensure    = "Present"
            Force     = $True
        }

    }

    Node $AllNodes.Where{$_.Role -contains "MemberServer"}.NodeName {
    
       MemberServer MemberConfig {
            Ensure    = "Present"
        }
    }

    Node $AllNodes.Where{$_.Role -contains "WebServer"}.NodeName {
    
       WebServer WebConfig {
            Ensure    = "Present"
        }

    }

    Node $AllNodes.NodeName {
    
        Registry NodeConfig {
            Key       = "HKEY_LOCAL_MACHINE\SOFTWARE\AddLevel\DSCConfig\Node"
            ValueName = "NodeVersion"
            ValueData = $Node.NodeVersion
            ValueType = "String"
            Ensure    = "Present"
            Force     = $True
        }

    }
}




#ConfigData composition: https://msdn.microsoft.com/en-us/powershell/dsc/configdata
$ConfigurationData = @{
    AllNodes = @(
        @{
            NodeName = "*"
        },
        @{
            NodeName    = "localhost"
            NodeVersion = "1.0"
            Role        = "MemberServer"            
        }
    )
    NonNodeData = ""
}

ServerConfig -ConfigurationData $ConfigurationData -OutputPath $env:TEMP -Verbose
#[Environment]::SetEnvironmentVariable("PSModulePath", $currentModulePath, "Machine")
#ise $env:temp\localhost.mof

#Start-DscConfiguration -path $env:TEMP -wait -verbose -force

